shopping-list-example
=====================

Shopping List Example

Exercise2: [Knockout.js](http://knockoutjs.com/) integration

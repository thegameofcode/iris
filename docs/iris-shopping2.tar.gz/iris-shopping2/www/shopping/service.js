iris.service(function(self){
    self.load = function (path, success, error) {
        self.get(iris.baseUri() + path, success, error);
    };
}, "/shopping/service.js");
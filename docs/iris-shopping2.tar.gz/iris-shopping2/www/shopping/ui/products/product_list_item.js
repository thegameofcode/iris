iris.ui(function(self) {	
    self.create = function() {  
        self.tmplMode(self.APPEND);
        var product = self.setting("product");                
        self.tmpl("/shopping/ui/products/product_list_item.html", product);
        self.get("product").change(function (event) {
            if (this.checked) {
                iris.notify(model.event.PRODUCTS.ADD, {
                    idProduct:product.idProduct, 
                    nameProduct:product.nameProduct
                });
            } else {
                iris.notify(model.event.PRODUCTS.REMOVE, product.idProduct);
            }
        });
    };
}, "/shopping/ui/products/product_list_item.js");
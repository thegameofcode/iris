iris.ui(function(self) {	
    self.create = function() {
        
        function _inflate(products) {
            $.each(products,
                function(index, product) {
                    self.ui("list_products", "/shopping/ui/products/product_list_item.js", {
                        "product": product
                    });
                }
                );
        }
        
        var category = self.setting("category");
        self.tmplMode(self.APPEND);
        self.tmpl("/shopping/ui/products/category_list_item.html", category);
        
        model.service.app.getProducts(category.idCategory, _inflate);
        
    };	
    
}, "/shopping/ui/products/category_list_item.js");
iris.screen(
    function (self) {
        
        function _inflate(categories) {
            $.each(categories,
                function(index, category) {						
                    self.ui("list_categories", "/shopping/ui/products/category_list_item.js", {
                        "category": category
                    });
                }
                );
        }
        
        function _check() {
            $("[data-product]").prop('checked', false);
            var products = model.shoppingList.getShoppingProducts();
            if (products.length > 0) {                
                $.each(products,
                    function(index, product) {
                        var checkbox = $("[data-product="+ product.idProduct + "]");
                        if (checkbox.size() > 0) {
                            checkbox.prop('checked', true);
                        }
                    }
                    );
            }
        }
        
        self.create = function () {
            self.tmpl("/shopping/screen/products/categories.html");
            model.service.app.getCategories(_inflate);
        };
        
        self.awake = function () {
            _check();
        };
        
    }, "/shopping/screen/products/categories.js");
/*global QUnit:false, module:false, test:false, asyncTest:false, expect:false*/
/*global start:false, stop:false ok:false, equal:false, notEqual:false, deepEqual:false*/
/*global notDeepEqual:false, strictEqual:false, notStrictEqual:false, raises:false*/
(function($) {

    /*
    ======== A Handy Little QUnit Reference ========
    http://docs.jquery.com/QUnit

    Test methods:
      expect(numAssertions)
      stop(increment)
      start(decrement)
    Test assertions:
      ok(value, [message])
      equal(actual, expected, [message])
      notEqual(actual, expected, [message])
      deepEqual(actual, expected, [message])
      notDeepEqual(actual, expected, [message])
      strictEqual(actual, expected, [message])
      notStrictEqual(actual, expected, [message])
      raises(block, [expected], [message])
  */
 
    iris.cache(false);
    iris.enableLog("localhost");

    function clearBody() {
        var irisGeneratedCode = $("#start_iris").nextAll();
        if (irisGeneratedCode !== undefined) {
            irisGeneratedCode.remove();
        }
    }
    
    
    module( "View Test", {
        setup: function() {            
            iris.init();
            iris.baseUri("../www");
            model.init();
            iris.welcome("/shopping/screen/welcome.js");
        },
        teardown: function () {
            model.destroy();
            window.location.hash ="";
            clearBody();
        }
    });
    
    asyncTest("Test add products to the Shopping List", function() {
        var products = [];
        window.expect(1);
        
        model.service.app.getProducts(2,
            function(data) {
                products = data;
            }
            );
        
        iris.goto("#products?idCategory=2");
                
        window.setTimeout(function() {
            $("input[type='checkbox']", "[data-id='list_products']").trigger('click');
            window.ok(model.shoppingList.getShoppingProducts().length === products.length, "All products in idCaterory=2 are selected");
            window.start();
        }, 500);
    }
    );
        
        
        
    asyncTest("Test check product", function() {
        var products = [];
        window.expect(1);
        
        model.service.app.getProducts(2,
            function(data) {
                products = data;
            }
            );
        
        iris.goto("#products?idCategory=2");
                
        window.setTimeout(function() {
            $("input[type='checkbox']", "[data-id='list_products']").trigger('click');
            iris.goto("#shopping");
            
            window.setTimeout(function () {
                $("button[data-id='buy']").first().trigger("click");
                model.ShoppingList.prototype.removePurchased();
                window.ok(model.shoppingList.getShoppingProducts().length === products.length - 1, "Removed 1 purchased product");
                window.start();
            }, 500);
        }, 500);
    }
    );
        
}(jQuery));
iris.ui(function(self) {	
    self.create = function() {
        var category = self.setting("category");
        self.tmplMode(self.APPEND);
        self.tmpl("shopping/ui/products/category_list_item.html", category);
    };	
}, "shopping/ui/products/category_list_item.js");
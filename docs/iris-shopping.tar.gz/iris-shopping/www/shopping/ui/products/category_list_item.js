iris.ui(function(self) {	
    
    self.create = function() {
        self.tmplMode(self.APPEND);
        var category = self.setting("category");
        self.tmpl("/shopping/ui/products/category_list_item.html", category);
    };	
    
}, "/shopping/ui/products/category_list_item.js");
iris.ui(function(self) {	
    self.create = function() {  
        self.tmplMode(self.APPEND);
        var product = self.setting("product");                
        self.tmpl("/shopping/ui/products/product_list_item.html", product);
    };
}, "/shopping/ui/products/product_list_item.js");
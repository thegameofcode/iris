iris.screen(
    function (self) {
        
        function _inflate(categories) {
            $.each(categories,
                function(index, category) {						
                    self.ui("list_categories", "/shopping/ui/products/category_list_item.js", {
                        "category": category
                    });
                }
                );
        }
        
        self.create = function () {
            self.tmpl("/shopping/screen/products/categories.html");
            model.service.app.getCategories(_inflate);
        };

        
    }, "/shopping/screen/products/categories.js");
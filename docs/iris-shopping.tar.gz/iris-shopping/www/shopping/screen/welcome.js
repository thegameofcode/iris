iris.screen(
    function (self) {	
        self.create = function () {
            
            function _ajaxPrepare() {
                $.ajaxPrefilter(function( options, originalOptions, jqXHR ) {            
                    self.get("screens").hide();
                    self.get("loading").show();                
                    jqXHR.always(function() {
                        self.get("loading").hide();
                        self.get("screens").show();
                    });            
                });                
            }
            
            function _createScreens() {
                self.screen("screens", "#home", "shopping/screen/home.js");
                self.screen("screens", "#categories", "shopping/screen/products/categories.js");
                self.screen("screens", "#products", "shopping/screen/products/products.js");            
                self.screen("screens", "#shopping", "shopping/screen/list/shopping.js");
            }
        
            function _changeLang(link) {
                var regExp = /[?&]lang=[a-z][a-z][\-_][A-Z][A-Z]/;
                var lang = window.location.href.match(regExp);
                var url = window.location.href;
                if ( lang === null) {
                    lang = "lang=" + link.data("lang");
                    if (window.location.href.match(/[?]/)) {
                        lang = "&" + lang;                            
                    } else {
                        lang = "?" + lang;
                    }
                    url += lang;
                } else {
                    var first = lang[0].substr(0,6);
                    url = window.location.href.replace(regExp, first + link.data("lang"));                       
                }
                    
                window.location.href = url;
                window.location.reload(true);
            }
            
            
            iris.translations("es_ES", {    
                LOADING: "Cargando...",
                MENU: {
                    WELCOME: "Ejemplo de lista de la compra",
                    HOME: "Incio",
                    PRODUCTS: "Productos",
                    SHOPPING_LIST:"Lista de la compra"
                }
            });
            
            iris.translations("en_US", {
                LOADING: "Loading...",
                MENU: {
                    WELCOME: "Shopping List Example",
                    HOME: "Home",
                    PRODUCTS: "Products",
                    SHOPPING_LIST: "Shopping List"
                }
            });
            
            
            self.tmpl("shopping/screen/welcome.html");
            
            _ajaxPrepare();
            
            _createScreens();
            
            $("[data-lang]").click(
                function (event) {
                    _changeLang($(this));
                    event.preventDefault();
                }
                );
            
            
            if ( !document.location.hash ) {                
                iris.goto("#home"); //Default page
            }
        };
    } , "shopping/screen/welcome.js");

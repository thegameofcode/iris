$(document).ready(
    function () {
        
        function _setLang() {    
            var regExp = /[?&]lang=[a-z][a-z][\-_][A-Z][A-Z]/;
            var lang = window.location.href.match(regExp);
            if ( lang !== null) {
                iris.locale(lang[0].substring(lang[0].length - 5, lang[0].length));
            } else {
                iris.locale("en_US");
            }
        }
            
        iris.translations("es_ES", {                
            ERROR: "Se ha producido el siguiente error",
            JQUERY : {
                DATATABLES: {
                    SEARCH: "Buscar",
                    NEXT: "Siguiente",
                    PREVIOUS: "Anterior",
                    SHOW: "Mostrando _MENU_ líneas"
                }
            }
            
        });
            
        iris.translations("en_US", {                
            ERROR: "There was an error",
            JQUERY : {
                DATATABLES: {
                    SEARCH: "Search",
                    NEXT: "Next",
                    PREVIOUS: "Previous",
                    SHOW: "Show _MENU_ entries"
                }
            }
        });

        _setLang();
        
        iris.welcome("shopping/screen/welcome.js");
                                
    }
);
var model = {}; 

(function($) {
    
    model.event = {
        
        PRODUCTS: {
            ADD: "shopping:products:add",
            REMOVE: "shopping:products:remove"
        },
        
        SHOPPING: {
            CHECK: "shopping:products:check",
            UNCHECK: "shopping:products:uncheck",
            CHANGE_STATE: "shopping:products:change_state",
            REMOVE_ALL: "shopping:products:remove_all",
            CHECK_ALL: "shopping:products:check_all",
            UNCHECK_ALL: "shopping:products:uncheck_all",
            INVERT_CHECK: "shopping:products:invert_check",
            REMOVE_CHECKED: "shopping:products:remove_purchased"
        }
    };

    function init () {
        model.shoppingList = new model.ShoppingList();
        iris.on(model.event.PRODUCTS.REMOVE, model.shoppingList.removeShoppingProduct);
        iris.on(model.event.PRODUCTS.ADD, model.shoppingList.addShoppingProduct);
        iris.on(model.event.SHOPPING.CHANGE_STATE, model.shoppingList.changeStateShoppingProduct);        
        iris.on(model.event.SHOPPING.REMOVE_ALL, model.shoppingList.removeAll);
        iris.on(model.event.SHOPPING.CHECK_ALL, model.shoppingList.checkAll);
        iris.on(model.event.SHOPPING.UNCHECK_ALL, model.shoppingList.uncheckAll);        
        iris.on(model.event.SHOPPING.INVERT_CHECK, model.shoppingList.invertCheck);  //Cuando un evento no existe no de ningún aviso, Me he vuelto loco porque no sabía que pasaba
        iris.on(model.event.SHOPPING.REMOVE_CHECKED, model.shoppingList.removePurchased);
        
    }
    
    function destroy () {
        model.shoppingList = null;
        iris.off(model.event.PRODUCTS.REMOVE, model.shoppingList.removeShoppingProduct);
        iris.off(model.event.PRODUCTS.ADD, model.shoppingList.addShoppingProduct);
        iris.off(model.event.SHOPPING.CHANGE_STATE, model.shoppingList.changeStateShoppingProduct);        
        iris.off(model.event.SHOPPING.REMOVE_ALL, model.shoppingList.removeAll);
        iris.off(model.event.SHOPPING.CHECK_ALL, model.shoppingList.checkAll);
        iris.off(model.event.SHOPPING.UNCHECK_ALL, model.shoppingList.uncheckAll);        
        iris.off(model.event.SHOPPING.INVERT_CHECK, model.shoppingList.invertCheck);  //Cuando un evento no existe no de ningún aviso, Me he vuelto loco porque no sabía que pasaba
        iris.off(model.event.SHOPPING.REMOVE_CHECKED, model.shoppingList.removePurchased);
        
    }
    
    model.ShoppingList =  function () {    
       
        var _shoppingProducts = [];
        var _order = 1;
    
        function _getShoppingProducts () {
            return _shoppingProducts;
        }
        
        function _getSortedShoppingProducts() {        
            var sortedShoppingProducts = [];
            var index = 0;
            var posPurchased = 0;
            
            for (; index < _shoppingProducts.length; index++) {
                var product = _shoppingProducts[index];                
                var purchased = product.purchased === true;
                var i = 0;
                var j = posPurchased;
                if (purchased) {
                    i = posPurchased;
                    j = sortedShoppingProducts.length;
                }
                
                while (i < j && sortedShoppingProducts[i].order < product.order) {
                    i++;
                }
                
                if (i < j) {
                    sortedShoppingProducts.splice(i, 0, product);                    
                } else {
                    if (purchased) {
                        sortedShoppingProducts.push(product);
                    } else {
                        sortedShoppingProducts.splice(posPurchased, 0, product);
                    }
                }
                if (!purchased) {
                    posPurchased++;
                }
            }
            
            
            return sortedShoppingProducts;
        }
        
        function _getShoppingProduct(idProduct) {
            var i = _getShoppingProductIndex(idProduct);            
            if (i === -1) {
                return null;
            } else {
                return _shoppingProducts[i];
            }
        }
        
        function _getShoppingProductIndex(idProduct) {
            var found = false;
            var i = 0;
            while ( !found && i < _shoppingProducts.length ) {
                if (_shoppingProducts[i].idProduct === idProduct) {
                    found = true;
                } else {
                    i++;
                }
            }
            
            if (found) {
                return i;
            } else {
                return -1;
            }
        }
        
        function _addShoppingProduct (product) {
            if (_getShoppingProduct(product.idProduct) === null) {
                var shoppingProduct = new model.ShoppingProduct(product.idProduct, product.nameProduct, false);
                shoppingProduct.order = _order;                
                _order++;
                _shoppingProducts.push(shoppingProduct);
                
            } else {
                throw "The product is already in the shopping list.";
            }
        }
        
        
        function _removeShoppingProduct (idProduct) {            
            var i = _getShoppingProductIndex(idProduct);
            if (i >= 0) {
                _shoppingProducts.splice(i, 1);
            }
        }
        
        function _removeAll () {                        
            _shoppingProducts = [];
            _order = 1;
        }
        
        
        function _changeStateShoppingProduct(idProduct, purchased) {            
            var shoppingProduct = _getShoppingProduct(idProduct);
            if (shoppingProduct !== null) {
                if (purchased === undefined) {
                    shoppingProduct.changeState(!shoppingProduct.purchased);
                } else {               
                    shoppingProduct.changeState(purchased === true);
                }
            }
        }
        
        function _changeStateAllShoppingProducts(purchased) {                    
            for (var i = 0; i < _shoppingProducts.length; i++) {
                var product = _shoppingProducts[i];             
                
                if (purchased === true || purchased === false) {                   
                    product.purchased = purchased;
                } else {
                    product.purchased = !product.purchased;
                }
            }
        }
        
        function _removePurchased() {            
            var i = 0;
            while (i < _shoppingProducts.length) {
                var product = _shoppingProducts[i];                
                if (product.hasOwnProperty("purchased") && product.purchased === true) {                   
                    _shoppingProducts.splice(i, 1);
                } else {
                    i++;
                }
            }
        }
        
        function _hasProducts(purchased) {
            var found = false;
            var i = 0;
            while ( !found && i < _shoppingProducts.length ) {
                if (_shoppingProducts[i].purchased === purchased) {
                    found = true;
                } else {
                    i++;
                }
            }
            
            return found;
        }
        
        
        model.ShoppingList.prototype.getShoppingProducts = _getShoppingProducts;
        model.ShoppingList.prototype.getSortedShoppingProducts = _getSortedShoppingProducts;
        model.ShoppingList.prototype.getShoppingProduct = _getShoppingProduct;
        model.ShoppingList.prototype.addShoppingProduct = _addShoppingProduct;
        model.ShoppingList.prototype.removeShoppingProduct = _removeShoppingProduct;
        model.ShoppingList.prototype.changeStateShoppingProduct = _changeStateShoppingProduct;
        model.ShoppingList.prototype.removeAll = _removeAll;
        model.ShoppingList.prototype.checkAll = function() {
            _changeStateAllShoppingProducts(true);
        };
        model.ShoppingList.prototype.uncheckAll = function() {
            _changeStateAllShoppingProducts(false);
        };
        model.ShoppingList.prototype.invertCheck = function() {
            _changeStateAllShoppingProducts();
        };
        model.ShoppingList.prototype.removePurchased = _removePurchased;
        
        model.ShoppingList.prototype.hasPurchasedProducts = function() {
            return _hasProducts(true);
        };
        
        model.ShoppingList.prototype.hasNoPurchasedProducts = function() {            
            return _hasProducts(false);
        };
    };
    
    
    
    model.ShoppingProduct = function (idProduct, nameProduct, purchased) {
        this.idProduct = idProduct;
        this.nameProduct = nameProduct;
        
        this.changeState = function (purchased) {
            if (purchased === true) {
                this.purchased = true;
            } else {
                this.purchased = false;
            }
        };
        
        this.changeState(purchased);
        
    };
    
    model.service = iris.service(function(self){
        self.load = function (path, success, error) {
            self.get(path, success, error);
        };
    });
    
    
    model.service.app = (function() {
        return {
            getCategories: function(success, error) {
                model.service.load("json/categories.json", success, error);
            },
            getProducts: function(idCategory, success, error) {
                model.service.load("json/category_" + idCategory + ".json", success, error);
            }
        };
    })();
    
    init();
    
})(jQuery);
iris.ui(function(self) {	
    self.create = function() {
        self.tmplMode(self.APPEND);
        var product = self.setting("product");                
        self.tmpl("shopping/ui/list/product_shopping_list_item.html", product);
    };	
}, "shopping/ui/list/product_shopping_list_item.js");
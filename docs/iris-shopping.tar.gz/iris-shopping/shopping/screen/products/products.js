iris.screen(
    function (self) {
        var _msg = null;
        
        self.create = function () { 
            
            iris.translations("es_ES", {                
                PRODUCTS: {
                    MISSING_CATEGORY: "Falta el parámetro <i>idCategoria</i>.",
                    CHOOSE_PRODUCTS: "Elige los productos que te interesen"
                }
            });
            
            iris.translations("en_US", {                
                PRODUCTS: {
                    MISSING_CATEGORY: "Missing <i>idCategory</i> parameter.",
                    CHOOSE_PRODUCTS: "Choose some products"
                }
            });
            
            self.tmpl("shopping/screen/products/products.html");
            _msg = self.get("msg");
            
            $("[data-id='list_products']").on("change", "input[type='checkbox']", function (event) {
                var idProduct = $(this).data("product");                
                var nameProduct = $(this).parent().text();
                if (this.checked) {
                    //model.shoppingList.addShoppingProduct(idProduct, nameProduct);
                    iris.notify(model.event.PRODUCTS.ADD, {
                        idProduct:idProduct, 
                        nameProduct:nameProduct
                    });
                } else {
                    //model.shoppingList.removeShoppingProduct(idProduct);
                    iris.notify(model.event.PRODUCTS.REMOVE, idProduct);
                }
            });
            
        };
       
        self.awake = function (params) {
            
            function _inflate(products) {
                _msg.html(iris.translate("PRODUCTS.CHOOSE_PRODUCTS") + ":"); 
                $.each(products,
                    function(index, product) {
                        if (model.shoppingList.getShoppingProduct(product.idProduct) !== null) {
                            product.checked = "checked";
                        } else {
                            product.checked = "";
                        }
                        self.ui("list_products", "shopping/ui/products/product_list_item.js", {
                            "product": product
                        });
                    }
                    );					
            }
            
            
            if (params.hasOwnProperty("idCategory")) {
                self.destroyUIs("list_products");
                model.service.app.getProducts(params.idCategory, _inflate,
                    function (p_request, p_textStatus, p_errorThrown) {
                        _msg.html(iris.translate("ERROR") + ": <i>" + p_textStatus + "</i>");
                    }
                    );
            }
        };
    }, "shopping/screen/products/products.js");
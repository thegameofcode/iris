shopping-list-example
=====================

Shopping List Example

Example of [Iris.js](https://github.com/iris-js/iris) use.
